var nombre;
var edad;
nombre = prompt('Ingresa tu nombre:','');
edad =prompt('Ingresa tu edad:','');
document.write('Hola ');
document.write(nombre);
document.write(' asi que tienes ');
document.write(edad);
document.write(' años');