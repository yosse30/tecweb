var nombre;
var nota;
nombre = prompt ('Ingresa tu nombre:','');
nota = prompt ('Ingresa tu nota:','');
if (nota>=5) {
    document.write(nombre+'esta aprobado con un'+nota);
}
