var x;
x = 1;
while (x<=100) {
    document.write(x);
    document.write(' ');
    x=x+1;
}