document.write("Cuidado <br>");
document.write("Ingresa tu documento correctamente <br>");
document.write("Cuidado <br>");
document.write("Ingresa tu documento correctamente <br>");
document.write("Cuidado <br>");
document.write("Ingresa tu documento correctamente <br>");
